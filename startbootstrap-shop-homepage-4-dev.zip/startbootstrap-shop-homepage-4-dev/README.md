Ajax Shopping Cart Example
Tutorial : http://www.sanwebe.com/2015/03/ajax-shopping-cart-with-php-and-jquery
License : http://opensource.org/licenses/MIT

1. Import "products_list.sql" using phpmyadmin.
2. Change database details and other settings in "config.inc.php"
3. Navigate to URL of extracted file on your web server using web browser.
